## Solutions to 0x17. Web stack debugging #3
- Devops
- Sysadmin
- Scripting
- Debugging
