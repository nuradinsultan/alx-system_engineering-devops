## Soultions to 0x16. API advanced
- Python
- Scripting
- Backend
- Api
