## Solutions to 0x1A. Application server
- Devops
- Systems Admin
