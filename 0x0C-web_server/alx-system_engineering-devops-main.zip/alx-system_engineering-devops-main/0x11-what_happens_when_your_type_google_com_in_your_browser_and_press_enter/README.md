## Solutions to 0x11. What happens when you type google.com in your browser and press Enter
- DevOps
- Network
- SysAdmin
