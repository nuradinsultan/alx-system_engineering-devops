# Solutions to tasks on Configuration Management (Automation) with Puppet
