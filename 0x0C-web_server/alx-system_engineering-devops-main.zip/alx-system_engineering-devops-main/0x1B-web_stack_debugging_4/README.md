## Solutions to 0x1B. Web stack debugging #4
- Devops
- Sysadmin
- Scripting
- Debugging
