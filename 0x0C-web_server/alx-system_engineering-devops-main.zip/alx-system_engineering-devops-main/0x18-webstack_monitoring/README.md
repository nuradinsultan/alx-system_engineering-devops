## Solutions to the tasks on 0x18. Webstack monitoring
- Devops
- Systems Administration
- Monitoring
