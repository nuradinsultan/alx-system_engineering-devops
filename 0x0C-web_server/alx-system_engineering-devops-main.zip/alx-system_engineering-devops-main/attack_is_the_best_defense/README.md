## Solutions to Attack is the best defense
- DevOps
- Scripting
- Hacking
