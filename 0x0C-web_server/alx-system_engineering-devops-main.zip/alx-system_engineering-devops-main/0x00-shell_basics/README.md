script prints the absolute path name of current working directory
