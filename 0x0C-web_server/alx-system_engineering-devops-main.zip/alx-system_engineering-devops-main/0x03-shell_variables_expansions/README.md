Task 0 : Create a script that creates an alias.



Task 1 : Create a script that prints hello user, where user is the current Linux user.



Task 2 : Create a script that Add /action to the PATH. /action (should be the last directory the shell looks into when looking for a program.)



Task 3 : Create a script that counts the number of directories in the PATH.



Task 4 : Create a script that lists environment variables.



Task 5 : Create a script that lists all local variables and environment variables, and functions.



Task 6 : Create a script that creates a new local variable.



Task 7 : Create a script that creates a new global variable.



Task 8 : Write a script that prints the result of the addition of 128 with the value stored in the environment variable TRUEKNOWLEDGE, followed by a new line.



Task 9 : Write a script that prints the result of POWER divided by DIVIDE, followed by a new line.



Task 10 : Write a script that displays the result of BREATH to the power LOVE



Task 11 : Write a script that converts a number from base 2 to base 10.



Task 12 : Create a script that prints all possible combinations of two letters, except oo



Task 13 : Write a script that prints a number with two decimal places, followed by a new line.




