## Solutions to 0x12. Web stack debugging #2
- DevOps
- SysAdmin
- Scripting
- Debugging
